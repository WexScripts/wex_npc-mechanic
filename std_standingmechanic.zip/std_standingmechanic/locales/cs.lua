return {
    mechanic = {
        menuTitle = "Místní mechanik",
        menuRepair = "Opravit vozidlo ($500)",
        menuWash = "Umytí vozidla ($100)",
        targetLabel = "Místní mechanik",
        repairing = "Mechanik opravuje vozidlo...",
        washing = "Mechanik myje vozidlo...",
        repairSuccess = "Vozidlo bylo opraveno!",
        washSuccess = "Vozidlo bylo umyto!",
        notEnoughMoney = "Nemáš dostatek peněz!",
        mustBeInVehicle = "Musíš sedět ve vozidle, abys mohl provádět akce mechanika!",
        blipName = "Místní mechanik",
    }
}